from tkinter import *
import tkinter.constants,tkinter.filedialog
from tkinter import filedialog

from Trainer import Trainer


knnRes= 0
knnScore =0
annRes= 0
annScore = 0
ensembleRes= 0

def reset():
    trainer.error = ''
    errText.set(trainer.error)
    
    if trainer.knnTable == None:
        knnStat.set("Not Trained")
    else:
        knnStat.set("Trained")
    if trainer.perceptron == None:
        annStat.set("Not Trained")
    else:
        annStat.set("Trained")
    if trainer.knnTable == None or trainer.perceptron == None:
        ensembleStat.set("Not Trained")
    else:
        ensembleStat.set("Trained")
    if trainer.newDataSetReady:
        trainSetStat.set("Ready")
    else:
        trainSetStat.set("Not Ready")

def generateKnn():
    
    reset()

    if trainer.newUrl == '':
        errText.set('Please choose an image')
        knnResult.set('')
        knnResultScore.set('')
        return
    
    knnRes = trainer.generateKNN()
    if knnRes == -1:
        knnResult.set('')
        knnResultScore.set('')
        errText.set(trainer.error)
        knnResult.set('')
        knnResultScore.set('')
        return
    
    knnScore = knnRes.confidenceScore
    knnResultScore.set(str(knnScore)[0:5] + '%')

    errText.set(trainer.error)

    if knnRes.output == 0:                     
        knnResult.set('YOUNG')
    else :
        knnResult.set('OLD')

    if trainer.knnTable == None:
        knnStat.set("Not Trained")
    else:
        knnStat.set("Trained")
    if trainer.knnTable == None or trainer.perceptron == None:
        ensembleStat.set("Not Trained")
    else:
        ensembleStat.set("Trained")
    if trainer.newDataSetReady:
        trainSetStat.set("Ready")
    else:
        trainSetStat.set("Not Ready")


def generateAnn():

    reset()

    if trainer.newUrl == '':
        errText.set('Please choose an image')
        annResultScore.set('')
        annResult.set('')
        return
    
    annRes = trainer.generatePerceptron()
    if annRes == -1:
        errText.set(trainer.error)
        annResultScore.set('')
        annResult.set('')
        return

    annScore = annRes.confidenceScore
    annResultScore.set(str(annScore)[0:5] + '%')

    errText.set(trainer.error)
    
    if annRes.output ==0:                     
        annResult.set('YOUNG')
    else :
        annResult.set('OLD')

    if trainer.perceptron == None:
        annStat.set("Not Trained")
    else:
        annStat.set("Trained")
    if trainer.knnTable == None or trainer.perceptron == None:
        ensembleStat.set("Not Trained")
    else:
        ensembleStat.set("Trained")
    if trainer.newDataSetReady:
        trainSetStat.set("Ready")
    else:
        trainSetStat.set("Not Ready")
        

def generateEnsemble():

    reset()

    if trainer.newUrl == '':
        errText.set('Please choose an image')
        annResultScore.set('')
        annResult.set('')
        knnResult.set('')
        knnResultScore.set('')
        return
    
    ensembleRes = trainer.generateEnsemble()
    if ensembleRes == -1:
        errText.set(trainer.error)
        annResultScore.set('')
        annResult.set('')
        knnResult.set('')
        knnResultScore.set('')
        return
    elif ensembleRes == -2:
        ensembleResult.set('UNKNOWN')
    
    errText.set(trainer.error)
    
    if ensembleRes == 0:                     
        ensembleResult.set('YOUNG')
    elif ensembleRes == 1:
        ensembleResult.set('OLD')

    if trainer.knnTable == None:
        knnStat.set("Not Trained")
    else:
        knnStat.set("Trained")
    if trainer.perceptron == None:
        annStat.set("Not Trained")
    else:
        annStat.set("Trained")
    if trainer.knnTable == None or trainer.perceptron == None:
        ensembleStat.set("Not Trained")
    else:
        ensembleStat.set("Trained")
    if trainer.newDataSetReady:
        trainSetStat.set("Ready")
    else:
        trainSetStat.set("Not Ready")

def getfile():

    try:
        filename = filedialog.askopenfilename()
        trainer.setNewURL(filename)
        sv.set(filename)
        errText.set(trainer.error)
        reset()
        annResultScore.set('')
        annResult.set('')
        knnResult.set('')
        knnResultScore.set('')
        ensembleResult.set('')
    except:
        reset()
        annResultScore.set('')
        annResult.set('')
        knnResult.set('')
        knnResultScore.set('')
        ensembleResult.set('')
        return

def url_callback(sv):
    trainer.setNewURL(sv.get())
    errText.set(trainer.error)
    reset()
    knnResult.set('')
    knnResultScore.set('')
    annResultScore.set('')
    annResult.set('')
    ensembleResult.set('')
    
def weightSlider_callback(this):
    trainer.setPerceptronEnsembleWeight(weightSlider.get())
    knnVal.set(str(round(1-weightSlider.get(), 1))[0:3])
    annVal.set(weightSlider.get())
    ensembleResult.set('')
    reset()

        



def scans_callback(this):
    trainer.setScans(scansSlider.get())
    reset()
    knnResult.set('')
    knnResultScore.set('')
    annResultScore.set('')
    annResult.set('')
    ensembleResult.set('')
    if trainer.newDataSetReady:
        trainSetStat.set("Ready")
    else:
        trainSetStat.set("Not Ready")
     
def gender_callback():
    gender = 'male'
    if v.get() == 1:
        gender = 'female'
    trainer.setGender(gender)
    reset()
    knnResult.set('')
    knnResultScore.set('')
    annResultScore.set('')
    annResult.set('')
    ensembleResult.set('')
    if trainer.newDataSetReady:
        trainSetStat.set("Ready")
    else:
        trainSetStat.set("Not Ready")
 
def kSlider_callback(this):
    trainer.setK(kSlider.get())
    reset()
    knnResult.set('')
    knnResultScore.set('')
    ensembleResult.set('')
     
def annThres_callback(this):
    trainer.setThresh(annThres.get())
    reset()
    annResultScore.set('')
    annResult.set('')
    ensembleResult.set('')

def annerrThres_callback(this):
    trainer.setErrThresh(annerrThres.get())
    reset()
    annResultScore.set('')
    annResult.set('')
    ensembleResult.set('')

def annlearnRate_callback(this):
    trainer.setLearnRate(learnRate.get())
    reset()
    annResultScore.set('')
    annResult.set('')
    ensembleResult.set('')

def cheek_callback():
    cheekB = True
    if cheekBox.get() == 0:
        cheekB = False
    trainer.setCheek(cheekB)
    reset()
    knnResult.set('')
    knnResultScore.set('')
    annResultScore.set('')
    annResult.set('')
    ensembleResult.set('')
    if trainer.newDataSetReady:
        trainSetStat.set("Ready")
    else:
        trainSetStat.set("Not Ready")

def lipBox_callback():
    lipB = True
    if lipBox.get() == 0:
        lipB = False
    trainer.setLips(lipB)
    reset()
    knnResult.set('')
    knnResultScore.set('')
    annResultScore.set('')
    annResult.set('')
    ensembleResult.set('')
    if trainer.newDataSetReady:
        trainSetStat.set("Ready")
    else:
        trainSetStat.set("Not Ready")

def undereye_callback():
    undereyeB = True
    if undereyeBox.get() == 0:
        undereyeB = False
    trainer.setUnderEye(undereyeB)
    reset()
    knnResult.set('')
    knnResultScore.set('')
    annResultScore.set('')
    annResult.set('')
    ensembleResult.set('')
    if trainer.newDataSetReady:
        trainSetStat.set("Ready")
    else:
        trainSetStat.set("Not Ready")

def oldOpt_callback(this):
    trainer.setOldAges(oldvariable.get())
    errText.set(trainer.error)
    reset()
    knnResult.set('')
    knnResultScore.set('')
    annResultScore.set('')
    annResult.set('')
    ensembleResult.set('')
    if trainer.newDataSetReady:
        trainSetStat.set("Ready")
    else:
        trainSetStat.set("Not Ready")

def youngOpt_callback(this):
    trainer.setYoungAges(youngvariable.get())
    errText.set(trainer.error)
    reset()
    knnResult.set('')
    knnResultScore.set('')
    annResultScore.set('')
    annResult.set('')
    ensembleResult.set('')
    if trainer.newDataSetReady:
        trainSetStat.set("Ready")
    else:
        trainSetStat.set("Not Ready")


def prepareTrainingSets():

    if not trainer.newDataSetReady:
        trainer.calculateDataSetFeatures()
    
    if trainer.newDataSetReady:
        trainSetStat.set("Ready")
    else:
        trainSetStat.set("Not Ready")




root = Tk()
root.title(' Human Facial Age Classifiers Ensemble')  
root.geometry("1000x700")
root.resizable(False, False)

frame = Frame(root,width=1000,height=700)
frame.pack(side=TOP)
leftFrame = Frame(frame,width=500,height=700,bg='white')
leftFrame.pack(fill='both',side=LEFT)
rightFrame = Frame(frame,width=500,height=700,bg='gray')
rightFrame.pack(fill='both',side=RIGHT)


knnLabel1 = Label(root,font=(12),text="K-Nearest Neighbor (KNN)",fg="red",bg='white')
knnLabel1.place(x=20,y=20)

knnLabel2 = Label(root,text="K  Value ",fg="red",bg='white')
knnLabel2.place(x=20,y=60)
kSlider = Scale(root, from_=1, to=50, orient=HORIZONTAL,bg='white',command=kSlider_callback)
kSlider.set(15)
kSlider.place(x=20,y=80)

knnLabel3 = Label(root,text="KNN Result ",fg="red",bg='white')
knnLabel3.place(x=30,y=160)
knnGenerateB = Button(root, text="Generate",fg="red",bg='white',command=generateKnn)
knnGenerateB.place(x=30,y=180)
knnResult = StringVar()
knnEntry = Entry(root,state='disabled',textvariable=knnResult)
knnEntry.place(x=200,y=160)

knnResultScore = StringVar()
knnEntryScore = Entry(root,state='disabled',textvariable=knnResultScore)
knnEntryScore.place(x=325,y=160)

knnLabel4 = Label(root,text="Status ",fg="red",bg='white')
knnLabel4.place(x=30,y=140)
knnStat = StringVar()
knnEntry1 = Entry(root,state='disabled',textvariable=knnStat)
knnEntry1.place(x=200,y=140)
knnStat.set("Not Trained")


AnnLabel1 = Label(root,font=(12),text="Artificial Neural Network (ANN)",fg="red",bg='white')
AnnLabel1.place(x=20,y=240)

AnnLabel3 = Label(root,text="ANN Result ",fg="red",bg='white')
AnnLabel3.place(x=30,y=400)
AnnGenerateB = Button(root, text="Generate",fg="red",bg='white',command=generateAnn)
AnnGenerateB.place(x=30,y=420)
annResult = StringVar()
annEntry = Entry(root,state='disabled',textvariable=annResult)
annEntry.place(x=200,y=400)

annResultScore = StringVar()
annEntryScore = Entry(root,state='disabled',textvariable=annResultScore)
annEntryScore.place(x=325,y=400)

annLabel4 = Label(root,text="Status ",fg="red",bg='white')
annLabel4.place(x=30,y=380)
annStat = StringVar()
annEntry1 = Entry(root,state='disabled',textvariable=annStat)
annEntry1.place(x=200,y=380)
annStat.set("Not Trained")

annLabel5 = Label(root,text="Threshold  Φ",fg="red",bg='white')
annLabel5.place(x=30,y=280)
annThres = Scale(root,length=200,width=5 ,from_=-5, to=5, resolution=0.1,orient=HORIZONTAL,command=annThres_callback)
annThres.place(x=200,y=280)

annLabel6 = Label(root,text="Error Threshold ",fg="red",bg='white')
annLabel6.place(x=30,y=310)
annerrThres = Scale(root,length=200,width=5 ,from_=0, to=0.99, resolution=0.01,orient=HORIZONTAL,command=annerrThres_callback)
annerrThres.place(x=200,y=310)
annerrThres.set(0.01)


annLabel7 = Label(root,text="Learning Rate η ",fg="red",bg='white')
annLabel7.place(x=30,y=340)
learnRate = Scale(root,length=200,width=5 ,from_=0.01, to=1, resolution=0.01,orient=HORIZONTAL,command=annlearnRate_callback)
learnRate.place(x=200,y=340)
learnRate.set(1)


ensembleLabel1 = Label(root,font=(12),text="Ensemble (KNN + ANN)",fg="red",bg='white')
ensembleLabel1.place(x=20,y=500)

ensembleLabel2 = Label(root,text="Ensemble Result ",fg="red",bg='white')
ensembleLabel2.place(x=30,y=610)
ensembleGen = Button(root, text="Generate",fg="red",bg='white',command=generateEnsemble)
ensembleGen.place(x=30,y=630)
ensembleResult = StringVar()
ensembleEntry = Entry(root,state='disabled',textvariable=ensembleResult)
ensembleEntry.place(x=200,y=610)

ensembleLabel4 = Label(root,text="Status ",fg="red",bg='white')
ensembleLabel4.place(x=30,y=590)
ensembleStat = StringVar()
ensembleEntry1 = Entry(root,state='disabled',textvariable=ensembleStat)
ensembleEntry1.place(x=200,y=590)
ensembleStat.set("Not Trained")

ensembleLabel5 = Label(root,text="KNN ",fg="red",bg='white')
ensembleLabel5.place(x=130,y=540)

knnVal = StringVar()
ensembleLabel7 = Label(root,textvariable=knnVal,fg="red",bg='white')
ensembleLabel7.place(x=135,y=560)

annVal = StringVar()
ensembleLabel8 = Label(root,textvariable=annVal,fg="red",bg='white')
ensembleLabel8.place(x=365,y=560)

ensembleLabel6 = Label(root,text="ANN ",fg="red",bg='white')
ensembleLabel6.place(x=360,y=540)
weightSlider = Scale(root,length=150,width=15,showvalue=0, from_=0, to=1,resolution=0.1, orient=HORIZONTAL,bg='white',command=weightSlider_callback)
weightSlider.set(0.5)
weightSlider.place(x=180,y=540)


optLabel = Label(root,font=(12), text="Choose Your Training Sets ",fg="white",bg='gray')
optLabel.place(x=520,y=5)

prepareBut = Button(root, text="Prepare",bg='white',command=prepareTrainingSets)
prepareBut.place(x=735,y=6)

trainSetStat = StringVar()
trainSetStatEntry1 = Entry(root,state='disabled',textvariable=trainSetStat)
trainSetStatEntry1.place(x=800,y=9)
trainSetStat.set("Not Ready")

OptionList = ["10_14","15_19","20_24","25_29",
"30_34","35_49","40_44","45_49",
"50_54","55_59","60_94"]

trainlabel = Label(root, text="Young Training Set  ",fg="white",bg='gray')
trainlabel.place(x=520,y=40)
youngvariable = StringVar(root)
youngvariable.set(OptionList[2])
youngopt = OptionMenu(root, youngvariable, *OptionList,command=youngOpt_callback)
youngopt.config(width=10, font=('Helvetica', 9))
youngopt.place(x=520,y=60)


scanslabel = Label(root, text="Total Number of Scans  ",fg="white",bg='gray')
scanslabel.place(x=700,y=80)
scansSlider = Scale(root,length=200,width=8, from_=2, to=500, orient=HORIZONTAL,bg='white',command=scans_callback)
scansSlider.place(x=700,y=100)
scansSlider.set(150)


trainlabel = Label(root, text="Old Training Set  ",fg="white",bg='gray')
trainlabel.place(x=520,y=100)
oldvariable = StringVar(root)
oldvariable.set(OptionList[9])
oldopt = OptionMenu(root, oldvariable, *OptionList,command=oldOpt_callback)
oldopt.config(width=10, font=('Helvetica', 9))
oldopt.place(x=520,y=120)


v = IntVar()
v.set(0) 
RB1 = Radiobutton(root,
                                   text="Male",
                                   variable=v, value=0,command=gender_callback)
RB2 = Radiobutton(root,
                                   text="Female",
                                   variable=v, value=1,command=gender_callback)
RB1.place(x=570,y=190)
RB2.place(x=650,y=190)

fileBtn = Button(frame, text="Choose File", fg="black",command=getfile)
fileBtn.place(x=715,y=400)


sv = StringVar()      
sv.trace("w", lambda name, index, mode, sv=sv: url_callback(sv))
urlEntry = Entry(root, textvariable=sv, width=50)
urlEntry.place(x=600,y=350)

featureslabel = Label(root,font=(11), text="Select Features   ",fg="white",bg='gray')
featureslabel.place(x=580,y=240)
cheekBox = IntVar()
Checkbutton(root, text="Cheeks",bg='gray', variable=cheekBox,command=cheek_callback).place(x=700,y=240)
undereyeBox = IntVar()
Checkbutton(root, text="Under Eyes",bg='gray', variable=undereyeBox,command=undereye_callback).place(x=700,y=260)
lipBox = IntVar()
Checkbutton(root, text="Lips",bg='gray', variable=lipBox,command=lipBox_callback).place(x=700,y=280)
cheekBox.set(1)
lipBox.set(1)
undereyeBox.set(1)
errText = StringVar()
errLabel = Label(root,font=('Helvetica 16'),textvariable=errText,fg="tomato4",bg='GRAY')
errLabel.place(x=520,y=600)

gender = ''
if v.get() ==0 :
    gender = 'male'
else:
    gender = 'female'

cheekB = True
if cheekBox.get() == 0:
    cheekB = False
underEyeB = True
if undereyeBox.get() == 0:
    underEyeB = False
lipB = True
if lipBox.get() == 0:
    lipB = False


trainer = Trainer(gender, youngvariable.get(), oldvariable.get(), scansSlider.get(), kSlider.get(), annThres.get(), annerrThres.get(), learnRate.get(), 100, cheekB, underEyeB, lipB, weightSlider.get())

root.mainloop()
