import cv2
import numpy as np
import dlib

from IsolatedFeatures import IsolatedFeatures

class ImageProcessor:
    def __init__(this):
        this.detector = dlib.get_frontal_face_detector()
        this.predictor =  dlib.shape_predictor("shape_predictor_68_face_landmarks.dat")

    # feature = 0 -> cheeks | 1 -> under eyes | 2 -> lips
    def calculateBlackPercentage(this, url, feature, AdaptiveBlockSize, AdaptiveC):
        img = cv2.imread(url)
        img = cv2.resize(img, (320, 400),  interpolation = cv2.INTER_AREA)

        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

        faces = this.detector(gray)

        if len(faces) == 0 or len(faces) > 1:
            return -1

        face = faces[0]
        
        landmarks = this.predictor(gray, face)
        features = IsolatedFeatures(landmarks)

        FullPoly = features.FullFace

        LeftPoly = None
        RightPoly = None

        if feature == 0:
            LeftPoly = features.LeftCheek
            RightPoly = features.RightCheek
        elif feature == 1:
            LeftPoly = features.LeftUnderEye
            RightPoly = features.RightUnderEye
        else:
            FullPoly = features.FullCheeks
            LeftPoly = features.LeftLips
            RightPoly = features.RightLips

        #Average Face Brightness
        fullMask = np.zeros((img.shape[0], img.shape[1]))
        cv2.fillConvexPoly(fullMask, FullPoly, 1)
        fullMask = fullMask.astype(np.bool)
        AVG_pix_gray = np.sum(gray[fullMask]) / np.sum(fullMask == 1)
        (thresh, blackAndWhiteImage) = cv2.threshold(gray, AVG_pix_gray, 255, cv2.THRESH_BINARY)

        LeftMask = np.zeros((img.shape[0], img.shape[1]))
        cv2.fillConvexPoly(LeftMask, LeftPoly, 1)
        LeftMask = LeftMask.astype(np.bool)
        LeftBlackPix = int((np.sum(blackAndWhiteImage[LeftMask] == 0) / np.sum(LeftMask == 1)) * 100)

        RightMask = np.zeros((img.shape[0], img.shape[1]))
        cv2.fillConvexPoly(RightMask, RightPoly, 1)
        RightMask = RightMask.astype(np.bool)
        RightBlackPix = int((np.sum(blackAndWhiteImage[RightMask] == 0) / np.sum(RightMask == 1)) * 100)

        if LeftBlackPix < RightBlackPix:
            mask = LeftMask
        else:
            mask = RightMask

        blackAndWhiteImage = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_MEAN_C,
                                                   cv2.THRESH_BINARY, AdaptiveBlockSize, AdaptiveC)
        return int((np.sum(blackAndWhiteImage[mask] == 0) / np.sum(mask == 1)) * 100)
