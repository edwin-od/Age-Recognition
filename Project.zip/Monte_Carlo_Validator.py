import random

from KNN import Iteration
from KNN import KNNTable

from ImageProcessor import ImageProcessor
IMGProcessor = ImageProcessor()


urlYoung = 'cropped\\128\\male\\age_20_24\\pic_'
urlOld = 'cropped\\128\\male\\age_55_59\\pic_'
scans = 100
YoungOffset = 50
OldOffset = 30
k = 7


arrYoungCheeks = []
arrOldCheeks = []

arrYoungUnderEye = []
arrOldUnderEye = []

arrYoungLips = []
arrOldLips = []

YoungScans = int(str(int(scans / 2)))

OldScans = int(str(int(scans / 2)))

randomset=[]
for i in range(1, scans+1, 1):
    randomset.append(i)
random.shuffle(randomset)  

CheeksBlockSize = 11
CheeksC = 4
UnderEyeBlockSize = 9 #11|7 or 9|7/6/5 -> 9|5 best
UnderEyeC = 5
LipsBlockSize = 7 #9|5/6/7 or 7|6 -> 9|6 or 7|5/6/7 -> 7|6 best small set - and 7|7 best big set
LipsC = 7
  
halfset=int(scans/2)

for r in range(0, YoungScans):
    #Training Young
    dirIndex = str(randomset[r] + YoungOffset).zfill(4)
    url = urlYoung + dirIndex + '.png'
    cheek = IMGProcessor.calculateBlackPercentage(url, 0, CheeksBlockSize, CheeksC)
    underEye = IMGProcessor.calculateBlackPercentage(url, 1, UnderEyeBlockSize, UnderEyeC)
    lips = IMGProcessor.calculateBlackPercentage(url, 2, LipsBlockSize, LipsC)
    if min(cheek, underEye, lips) == -1:
        YoungScans -= 1
        print('ERROR: Young Scans decreased from', YoungScans + 1, 'to', YoungScans)
        continue
    pr = 'Y_'+dirIndex+' -> '+'cheeks: '+str(cheek)+'% | under eye: '+str(underEye)+'% | lips: '+str(lips)+'%'
    print(pr)
    arrYoungCheeks.append(cheek)
    arrYoungUnderEye.append(underEye)
    arrYoungLips.append(lips)

for r in range(0, OldScans):
    #Training Old
    dirIndex = str(randomset[r] + OldOffset).zfill(4)
    url = urlOld + dirIndex + '.png'
    cheek = IMGProcessor.calculateBlackPercentage(url, 0, CheeksBlockSize, CheeksC)
    underEye = IMGProcessor.calculateBlackPercentage(url, 1, UnderEyeBlockSize, UnderEyeC)
    lips = IMGProcessor.calculateBlackPercentage(url, 2, LipsBlockSize, LipsC)
    if min(cheek, underEye, lips) == -1:
        OldScans -= 1
        print('ERROR: Old Scans decreased from', OldScans + 1, 'to', OldScans)
        continue
    pr = 'O_'+dirIndex+' -> '+'cheeks: '+str(cheek)+'% | under eye: '+str(underEye)+'% | lips: '+str(lips)+'%'
    print(pr)
    arrOldCheeks.append(cheek)
    arrOldUnderEye.append(underEye)
    arrOldLips.append(lips)

print()

#KNN
iterations = []

for i in range(0, YoungScans):
    iterations.append(Iteration([arrYoungCheeks[i],
                                arrYoungUnderEye[i],
                                arrYoungLips[i]],
                                'young'))

for i in range(0, OldScans):    
    iterations.append(Iteration([arrOldCheeks[i],
                                arrOldUnderEye[i],
                                arrOldLips[i]],
                                'old'))

YoungScans = int(str(int(scans / 2)))

OldScans = int(str(int(scans / 2)))

table = KNNTable(iterations, ['young', 'old'])

successyoung=0
failold=0
for r in range(halfset, halfset + YoungScans):
    #Testing Young
    dirIndex = str(randomset[r] + YoungOffset).zfill(4)
    url = urlYoung + dirIndex + '.png'
    cheek = IMGProcessor.calculateBlackPercentage(url, 0, CheeksBlockSize, CheeksC)
    underEye = IMGProcessor.calculateBlackPercentage(url, 1, UnderEyeBlockSize, UnderEyeC)
    lips = IMGProcessor.calculateBlackPercentage(url, 2, LipsBlockSize, LipsC)
    if min(cheek, underEye, lips) != -1:
        pr = 'I_(Y)_'+dirIndex+' -> '+'cheeks: '+str(cheek)+'% | under eye: '+str(underEye)+'% | lips: '+str(lips)+'%'
        print(pr)
    
        new = Iteration([
            cheek,
            underEye,
            lips],
                None)
        
        neighbors = table.findNeighbors(new, k)
        for n in neighbors:
            s = ''
            for f in n.featureValues:
                s += ' ' + str(f)
            s += ' ' + str(n.target)
            print(s)
        print('_________________________')
        result = table.process(new, k)
        print(result)
        print()
        if result=='young':
            successyoung+=1
        else:
            failold+=1
    else:
        YoungScans -= 1
        print('ERROR: Young Scans decreased from', YoungScans + 1, 'to', YoungScans)
        print()
        
successold=0
failyoung=0
for r in range(halfset, halfset + OldScans):
    #Testing Old
    dirIndex = str(randomset[r] + OldOffset).zfill(4)
    url = urlOld + dirIndex + '.png'
    cheek = IMGProcessor.calculateBlackPercentage(url, 0, CheeksBlockSize, CheeksC)
    underEye = IMGProcessor.calculateBlackPercentage(url, 1, UnderEyeBlockSize, UnderEyeC)
    lips = IMGProcessor.calculateBlackPercentage(url, 2, LipsBlockSize, LipsC)
    if min(cheek, underEye, lips) != -1:
        pr = 'I_(O)_'+dirIndex+'-> '+'cheeks: '+str(cheek)+'% | under eye: '+str(underEye)+'% | lips: '+str(lips)+'%'
        print(pr)
    
        new = Iteration([
            cheek,
            underEye,
            lips],
                None)
    
        neighbors = table.findNeighbors(new, k)
        for n in neighbors:
            s = ''
            for f in n.featureValues:
                s += ' ' + str(f)
            s += ' ' + str(n.target)
            print(s)
        print('_________________________')
        result = table.process(new, k)
        print(result)
        print()
        if result=='old':
            successold+=1
        else:
            failyoung+=1
    else:
        OldScans -= 1
        print('ERROR: Old Scans decreased from', OldScans + 1, 'to', OldScans)
        print()


print('##################### VALIDATION STATISTICS #####################')
print()
print('#### YOUNG ####')
print()
TPy = successyoung
FPy = failyoung
TNy = successold
FNy = failold

PRy = TPy / (TPy + FPy)
Ry = TPy / (TPy + FNy)
Fy = (2 * PRy * Ry) / (PRy + Ry)
AccY = (TPy + TNy) / (TPy + FPy + TNy + FNy)

print('Precision (young)', PRy)
print('Recall (young)', Ry)
print('F-value (young)', Fy)
#print('Accuracy (young)', int(AccY * 100))
print()
print()
print('##### OLD #####')
print()
TPo = successold
FPo = failold
TNo = successyoung
FNo = failyoung

PRo = TPo / (TPo + FPo)
Ro = TPo / (TPo + FNo)
Fo = (2 * PRo * Ro) / (PRo + Ro)
AccO = (TPo + TNo) / (TPo + FPo + TNo + FNo)

print('Precision (old)', PRo)
print('Recall (old)', Ro)
print('F-value (old)', Fo)
#print('Accuracy (old)', int(AccO * 100))
print()
print()
print('Accuracy', int(AccY * 100), '%')
