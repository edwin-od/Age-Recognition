import numpy as np

class Pair:
    def __init__(this, inputs, desired):
        this.inputs = inputs
        this.desired = desired
        
        

class Perceptron:        
    def __init__(this, nbInputs, thresh, errThresh, learnRate):
        this.nbInputs = nbInputs
        this.thresh = thresh
        this.errThresh = errThresh
        this.learnRate = learnRate
        this.weights = np.zeros((nbInputs, 1))
        this.maxV = float('-inf')
        this.minV = float('inf')
        
    def updateWeights(this, pair):
        y = this.generateOutput(pair.inputs)
        if this.checkMeanAbsError(pair.desired, y):
            deltaW = np.multiply(this.learnRate, (np.multiply((pair.desired - y), pair.inputs.T)).T)
            this.weights = np.add(this.weights, deltaW)
            return True
        return False

    def checkMeanAbsError(this, desired, y):
        f = abs(desired - y)
        if f <= this.errThresh:
            return False
        else:
            return True

    def generateOutput(this, inputs):
        v = np.subtract(np.matmul(this.weights.T, inputs), this.thresh)[0,0]

        if v > this.maxV:
            this.maxV = v
        elif v < this.minV:
            this.minV = v
        
        if v > 0:
            return 1
        else:
            return 0

    def generateOutputScore(this, inputs):
        v = np.subtract(np.matmul(this.weights.T, inputs), this.thresh)[0,0]

        if this.maxV == float('-inf'):
            this.maxV = thresh
        elif this.minV == float('inf'):
            this.minV = thresh

        topV = this.maxV - this.minV
        if topV == 0:
            return 100.0
        
        if v > 0:
            return (float(v - this.minV) / float(topV)) * 100.0
        else:
            return (1.0 - (float(v - this.minV) / float(topV))) * 100.0
        

    def setWeights(this, weights, minV, maxV):
        this.weights = weights
        this.maxV = maxV
        this.minV = minV


#Test Example Chapter 6 Exercise 6.4
##
##perceptron = Perceptron(4, 0, 0.01, 1)
##
##features1 = np.zeros((4, 1))
##features1[0,0] = 1
##features1[1,0] = 1
##features1[2,0] = 1
##features1[3,0] = 0
##
##pair1 = Pair(features1, 1)
##
##features2 = np.zeros((4, 1))
##features2[0,0] = 0
##features2[1,0] = 1
##features2[2,0] = 0
##features2[3,0] = 0
##
##pair2 = Pair(features2, 0)
##
##perceptron.updateWeights(pair1)
##perceptron.updateWeights(pair2)
##
##print(perceptron.weights)
