import cv2
import numpy as np
import os

from KNN import Iteration
from KNN import KNNTable

from Perceptron import Pair
from Perceptron import Perceptron

from ImageProcessor import ImageProcessor

class Result:
    def __init__(this, classifier, output, confidenceScore):
        this.classifier = classifier
        this.output = output
        this.confidenceScore = confidenceScore

class Trainer:
    def __init__(this, gender, youngAges, oldAges, scans, k, thresh, errThresh, learnRate, perceptronDivergingLimit, cheek, underEye, lips, perceptronEnsembleWeight):

        this.IMGProcessor = ImageProcessor()

        this.error = ''

        this.perceptronEnsembleWeight = perceptronEnsembleWeight

        this.gender = gender
        this.youngAges = youngAges
        this.oldAges = oldAges

        this.cheek = cheek
        this.underEye = underEye
        this.lips = lips

        this.cheekCenter = -1
        this.underEyeCenter = -1
        this.lipsCenter = -1

        this.newUrl = ''

        this.newReady = False
        
        this.newCheek = -1
        this.newUnderEye = -1
        this.newLips = -1
        
        this.urlYoung = 'cropped\\128\\'+this.gender+'\\age_'+this.youngAges
        this.urlOld = 'cropped\\128\\'+this.gender+'\\age_'+this.oldAges

        this.OriginalScans = scans
        
        this.scans = scans

        this.YoungScans = int(scans / 2)
        this.OldScans = int(scans / 2)

        this.youngDir = os.listdir(this.urlYoung)
        this.oldDir = os.listdir(this.urlOld)
        i=0
        l=len(this.youngDir)
        while(i<l):
            if not this.youngDir[i].endswith('.png') and not this.youngDir[i].endswith('.jpg') and not this.youngDir[i].endswith('.jpeg'):
                this.youngDir.pop(i)
                l = l - 1
                continue
            i = i + 1

        if len(this.youngDir) < this.YoungScans:
            this.YoungScans = len(this.youngDir)
        
        i=0
        l=len(this.oldDir)
        while(i<l):
            if not this.oldDir[i].endswith('.png') and not this.youngDir[i].endswith('.jpg') and not this.youngDir[i].endswith('.jpeg'):
                this.oldDir.pop(i)
                l = l - 1
                continue
            i = i + 1

        if len(this.oldDir) < this.OldScans:
            this.OldScans = len(this.oldDir)

        if this.YoungScans < this.OldScans:
            this.OldScans = this.YoungScans
        elif this.YoungScans > this.OldScans:
            this.YoungScans = this.OldScans

        this.scans = this.YoungScans + this.OldScans
        if this.scans < 2:
            this.error = 'Please choose a wider range of images'


        this.newDataSetReady = False

        this.arrYoungCheeks = []
        this.arrOldCheeks = []

        this.arrYoungUnderEye = []
        this.arrOldUnderEye = []

        this.arrYoungLips = []
        this.arrOldLips = []

        this.CheeksBlockSize = 11
        this.CheeksC = 4
        this.UnderEyeBlockSize = 9 #11|7 or 9|7/6/5 -> 9|5 best
        this.UnderEyeC = 5
        this.LipsBlockSize = 7 #9|5/6/7 or 7|6 -> 9|6 or 7|5/6/7 -> 7|6 best small set - and 7|7 best big set
        this.LipsC = 7

        this.k = k
        this.knnTable = None

        this.thresh = thresh
        this.errThresh = errThresh
        this.learnRate = learnRate
        this.perceptronDivergingLimit = perceptronDivergingLimit
        this.perceptron = None



    def setYoungAges(this, youngAges):

        this.YoungScans = int(this.OriginalScans / 2)
        
        this.youngAges = youngAges
        this.urlYoung = 'cropped\\128\\'+this.gender+'\\age_'+this.youngAges
        this.youngDir = os.listdir(this.urlYoung)

        i=0
        l=len(this.youngDir)
        while(i<l):
            if not this.youngDir[i].endswith('.png') and not this.youngDir[i].endswith('.jpg') and not this.youngDir[i].endswith('.jpeg'):
                this.youngDir.pop(i)
                l = l - 1
                continue
            i = i + 1

        if len(this.youngDir) < this.YoungScans:
            this.YoungScans = len(this.youngDir)

        if this.YoungScans < this.OldScans:
            this.OldScans = this.YoungScans
        elif this.YoungScans > this.OldScans:
            this.YoungScans = this.OldScans

        this.scans = this.YoungScans + this.OldScans
        if this.scans < 2:
            this.error = 'Please choose a wider range of images'
        this.newDataSetReady = False

    def setOldAges(this, oldAges):

        this.OldScans = int(this.OriginalScans / 2)
        
        this.oldAges = oldAges
        this.urlOld = 'cropped\\128\\'+this.gender+'\\age_'+this.oldAges
        this.oldDir = os.listdir(this.urlOld)

        i=0
        l=len(this.oldDir)
        while(i<l):
            if not this.oldDir[i].endswith('.png') and not this.youngDir[i].endswith('.jpg') and not this.youngDir[i].endswith('.jpeg'):
                this.oldDir.pop(i)
                l = l - 1
                continue
            i = i + 1

        if len(this.oldDir) < this.OldScans:
            this.OldScans = len(this.oldDir)

        if this.YoungScans < this.OldScans:
            this.OldScans = this.YoungScans
        elif this.YoungScans > this.OldScans:
            this.YoungScans = this.OldScans

        this.scans = this.YoungScans + this.OldScans
        if this.scans < 2:
            this.error = 'Please choose a wider range of images'
        this.newDataSetReady = False

    def setGender(this, gender):
        this.gender = gender
        this.newDataSetReady = False
        this.knnTable = None
        this.perceptron = None
    def setScans(this, scans):
        this.scans = scans
        this.newDataSetReady = False
        this.knnTable = None
        this.perceptron = None
    def setK(this, k):
        this.k = k
        this.knnTable = None
    def setThresh(this, thresh):
        this.thresh = thresh
        this.perceptron = None
    def setErrThresh(this, errThresh):
        this.errThresh = errThresh
        this.perceptron = None
    def setLearnRate(this, learnRate):
        this.learnRate = learnRate
        this.perceptron = None

    def setNewURL(this, url):
        this.newUrl = url
        this.newReady = False

    def setCheek(this, cheek):
        this.cheek = cheek
        this.knnTable = None
        this.perceptron = None
    def setUnderEye(this, underEye):
        this.underEye = underEye
        this.knnTable = None
        this.perceptron = None
    def setLips(this, lips):
        this.lips = lips
        this.knnTable = None
        this.perceptron = None

    def setPerceptronEnsembleWeight(this, perceptronEnsembleWeight):
        this.perceptronEnsembleWeight = perceptronEnsembleWeight

        

    def calculateDataSetFeatures(this):
        
        this.arrYoungCheeks = []
        this.arrOldCheeks = []

        this.arrYoungUnderEye = []
        this.arrOldUnderEye = []

        this.arrYoungLips = []
        this.arrOldLips = []

        this.YoungScans = int(this.scans / 2)
        this.OldScans = int(this.scans / 2)
        
        for r in range(0, this.YoungScans):
            url = this.urlYoung + '\\' + this.youngDir[r]
            cheek = this.IMGProcessor.calculateBlackPercentage(url, 0, this.CheeksBlockSize, this.CheeksC)
            underEye = this.IMGProcessor.calculateBlackPercentage(url, 1, this.UnderEyeBlockSize, this.UnderEyeC)
            lips = this.IMGProcessor.calculateBlackPercentage(url, 2, this.LipsBlockSize, this.LipsC)
            if min(cheek, underEye, lips) == -1:
                this.YoungScans -= 1
                print('ERROR: Young Scans decreased from', this.YoungScans + 1, 'to', this.YoungScans)
                continue
            pr = 'Y_'+str(r+1)+' -> '+'cheeks: '+str(cheek)+'% | under eye: '+str(underEye)+'% | lips: '+str(lips)+'%'
            print(pr)
            this.arrYoungCheeks.append(cheek)
            this.arrYoungUnderEye.append(underEye)
            this.arrYoungLips.append(lips)
            
        for r in range(1, this.OldScans + 1):
            dirIndex = str(r).zfill(4)
            url = this.urlOld + '\\' + this.oldDir[r]
            cheek = this.IMGProcessor.calculateBlackPercentage(url, 0, this.CheeksBlockSize, this.CheeksC)
            underEye = this.IMGProcessor.calculateBlackPercentage(url, 1, this.UnderEyeBlockSize, this.UnderEyeC)
            lips = this.IMGProcessor.calculateBlackPercentage(url, 2, this.LipsBlockSize, this.LipsC)
            if min(cheek, underEye, lips) == -1:
                this.OldScans -= 1
                print('ERROR: Old Scans decreased from', this.OldScans + 1, 'to', this.OldScans)
                continue
            pr = 'O_'+str(r+1)+' -> '+'cheeks: '+str(cheek)+'% | under eye: '+str(underEye)+'% | lips: '+str(lips)+'%'
            print(pr)
            this.arrOldCheeks.append(cheek)
            this.arrOldUnderEye.append(underEye)
            this.arrOldLips.append(lips)

        delta = this.YoungScans - this.OldScans
        if delta == 0:
            this.newDataSetReady = True
            return True
        elif delta > 0:
            for r in range(0, delta):
                this.arrYoungCheeks.pop()
                this.arrYoungUnderEye.pop()
                this.arrYoungLips.pop()
            this.YoungScans = this.OldScans
            if this.YoungScans <= 0 or this.OldScans <= 0:
                this.error = 'Please choose a wider range of images'
                this.newDataSetReady = False
                return False
            else:
                this.newDataSetReady = True
                return True
        else:
            for r in range(0, -delta):
                this.arrOldCheeks.pop()
                this.arrOldUnderEye.pop()
                this.arrOldLips.pop()
            this.OldScans = this.YoungScans
            if this.YoungScans <= 0 or this.OldScans <= 0:
                this.error = 'Please choose a wider range of images'
                this.newDataSetReady = False
                return False
            else:
                this.newDataSetReady = True
                return True


    def calculateNewFeatures(this):

        if this.newUrl == '' or this.newUrl == None or (not this.newUrl.endswith('.png') and not this.newUrl.endswith('.jpg') and not this.newUrl.endswith('.jpeg')):
            this.newCheek = -1
            this.newUnderEye = -1
            this.newLips = -1
            this.newReady = False
            this.error = 'Invalid input'
            return False

        try:
            img = cv2.imread(this.newUrl)
            img = cv2.resize(img, (320, 400),  interpolation = cv2.INTER_AREA)
            cv2.imshow("Face", img)
            this.newCheek = this.IMGProcessor.calculateBlackPercentage(this.newUrl, 0, this.CheeksBlockSize, this.CheeksC)
            this.newUnderEye = this.IMGProcessor.calculateBlackPercentage(this.newUrl, 1, this.UnderEyeBlockSize, this.UnderEyeC)
            this.newLips = this.IMGProcessor.calculateBlackPercentage(this.newUrl, 2, this.LipsBlockSize, this.LipsC)
            if min(this.newCheek, this.newUnderEye, this.newLips) != -1:
                this.newReady = True
                return True
            else:
                this.newCheek = -1
                this.newUnderEye = -1
                this.newLips = -1
                this.newReady = False
                this.error = 'Please choose a different input image'
                return False
        except:
            this.newCheek = -1
            this.newUnderEye = -1
            this.newLips = -1
            this.newReady = False
            this.error = 'Please choose a different input image'
            return False
            
    def trainKNN(this):

        if not this.cheek and not this.underEye and not this.lips:
            this.knnTable = None
            this.error = 'Please choose at least one feature'
            return

        if not this.newDataSetReady:
            this.calculateDataSetFeatures()
        
        iterations = []

        for i in range(0, this.YoungScans):
            features = []
            if this.cheek:
                features.append(this.arrYoungCheeks[i])
            if this.underEye:
                features.append(this.arrYoungUnderEye[i])
            if this.lips:
                features.append(this.arrYoungLips[i])
            iterations.append(Iteration(features, 'young'))

        for i in range(0, this.OldScans):
            features = []
            if this.cheek:
                features.append(this.arrOldCheeks[i])
            if this.underEye:
                features.append(this.arrOldUnderEye[i])
            if this.lips:
                features.append(this.arrOldLips[i])
            iterations.append(Iteration(features, 'old'))

        this.knnTable = KNNTable(iterations, ['young', 'old'])

    def generateKNN(this):

        if not this.newReady:
            if not this.calculateNewFeatures():
                return -1
        if not this.cheek and not this.underEye and not this.lips:
            this.knnTable = None
            this.error = 'Please choose at least one feature'
            return -1
        if this.knnTable == None or not this.newDataSetReady:
            this.trainKNN()

        features = []
        if this.cheek:
            features.append(this.newCheek)
        if this.underEye:
            features.append(this.newUnderEye)
        if this.lips:
            features.append(this.newLips)
        new = Iteration(features, None)
            
##        neighbors = this.knnTable.findNeighbors(new, this.k)
##        for n in neighbors:
##            s = ''
##            for f in n.featureValues:
##                s += ' ' + str(f)
##            s += ' ' + str(n.target)
##            print(s)
##        print('_________________________')
        result = this.knnTable.process(new, this.k)
##        print(result)
        score = this.knnTable.processScore(new, this.k)

        output = -1
        if result == 'young':
            output = 0
        elif result == 'old':
            output = 1

        return Result('KNN', output, score)


    def trainPerceptron(this):

        if not this.cheek and not this.underEye and not this.lips:
            this.error = 'Please choose at least one feature'
            this.perceptron = None
            return

        if not this.newDataSetReady:
            this.calculateDataSetFeatures()

        this.cheekCenter = (sum(this.arrOldCheeks) / len(this.arrOldCheeks)) - (sum(this.arrYoungCheeks) / len(this.arrYoungCheeks))
        this.underEyeCenter = (sum(this.arrOldUnderEye) / len(this.arrOldUnderEye)) - (sum(this.arrYoungUnderEye) / len(this.arrYoungUnderEye))
        this.lipsCenter = (sum(this.arrOldLips) / len(this.arrOldLips)) - (sum(this.arrYoungLips) / len(this.arrYoungLips))


        count = 0
        if this.cheek:
            count = count + 1
        if this.underEye:
            count = count + 1
        if this.lips:
            count = count + 1

        this.perceptron = Perceptron(count, this.thresh, this.errThresh, this.learnRate)

        for i in range(0, this.YoungScans + this.OldScans):
            
            j = i // 2
            
            if (i%2) == 0:

                features = np.zeros((count, 1))
                newcount = 0
                if this.cheek:
                    cheekVal = 0
                    if this.arrYoungCheeks[j] > this.cheekCenter:
                        cheekVal = 1
                    features[0,0] = cheekVal
                    newcount = newcount + 1
                if this.underEye:
                    underEyeVal = 0
                    if this.arrYoungUnderEye[j] > this.underEyeCenter:
                        underEyeVal = 1
                    features[newcount,0] = underEyeVal
                    newcount = newcount + 1
                if this.lips:
                    lipsVal = 0
                    if this.arrYoungLips[j] > this.lipsCenter:
                        lipsVal = 1
                    features[newcount,0] = lipsVal
                
                res = True
                counter = 0
                weights = np.copy(this.perceptron.weights)
                minV = this.perceptron.minV
                maxV = this.perceptron.maxV
                while res:
                    if counter == this.perceptronDivergingLimit:
                        this.perceptron.setWeights(weights, minV, maxV)
                        i = i + 1
                        break
                    res = this.perceptron.updateWeights(Pair(features, 0))
                    counter = counter + 1
            else:
                
                features = np.zeros((count, 1))
                newcount = 0
                if this.cheek:
                    cheekVal = 1
                    if this.arrOldCheeks[j] < this.cheekCenter:
                        cheekVal = 0
                    features[0,0] = cheekVal
                    newcount = newcount + 1
                if this.underEye:
                    underEyeVal = 1
                    if this.arrOldUnderEye[j] < this.underEyeCenter:
                        underEyeVal = 0
                    features[newcount,0] = underEyeVal
                    newcount = newcount + 1
                if this.lips:
                    lipsVal = 1
                    if this.arrOldLips[j] < this.lipsCenter:
                        lipsVal = 0
                    features[newcount,0] = lipsVal
                
                res = True
                counter = 0
                weights = np.copy(this.perceptron.weights)
                minV = this.perceptron.minV
                maxV = this.perceptron.maxV
                while res:
                    if counter == this.perceptronDivergingLimit:
                        this.perceptron.setWeights(weights, minV, maxV)
                        i = i + 1
                        break
                    res = this.perceptron.updateWeights(Pair(features, 1))
                    counter = counter + 1
            
    def generatePerceptron(this):

        if not this.newReady:
            if not this.calculateNewFeatures():
                return -1
        if not this.cheek and not this.underEye and not this.lips:
            this.error = 'Please choose at least one feature'
            this.perceptron = None
            return -1
        if this.perceptron == None or not this.newDataSetReady:
            this.trainPerceptron()

        count = 0
        if this.cheek:
                count = count + 1
        if this.underEye:
            count = count + 1
        if this.lips:
            count = count + 1

        features = np.zeros((count, 1))
        count = 0
        if this.cheek:
            cheekVal = 1
            if this.newCheek < this.cheekCenter:
                cheekVal = 0
            features[0,0] = cheekVal
            count = count + 1
        if this.underEye:
            underEyeVal = 1
            if this.newUnderEye < this.underEyeCenter:
                underEyeVal = 0
            features[count,0] = underEyeVal
            count = count + 1
        if this.lips:
            lipsVal = 1
            if this.newLips < this.lipsCenter:
                lipsVal = 0
            features[count,0] = lipsVal
        
        weights = np.copy(this.perceptron.weights)
        minV = this.perceptron.minV
        maxV = this.perceptron.maxV
        
        output = this.perceptron.generateOutput(features)
        
        this.perceptron.setWeights(weights, minV, maxV)
        
        score = this.perceptron.generateOutputScore(features)
        
        return Result('Perceptron', output, score)

    def generateEnsemble(this):

        perceptronOutput = this.generatePerceptron()
        knnOutput = this.generateKNN()

        if perceptronOutput == -1 or knnOutput == -1:
            return -1

        wPerceptron = this.perceptronEnsembleWeight * perceptronOutput.confidenceScore
        wKNN = (1.0 - this.perceptronEnsembleWeight) * knnOutput.confidenceScore

        if wPerceptron > wKNN:
            return perceptronOutput.output
        elif wPerceptron < wKNN:
            return knnOutput.output
        elif wPerceptron == wKNN and perceptronOutput.output == knnOutput.output:
            return knnOutput.output
        else:
            return -2
        
        
        

##trainer = Trainer('male', '20_24', '55_59', 150, 15, 0, 0.01, 1, 100, True, True, True, 0.3)
##
##trainer.setNewURL('cropped\\128\\male\\age_60_94\\pic_0042.png')
##
##perceptronOutput = trainer.generatePerceptron()
##print('Output Perceptron = ' + str(perceptronOutput.output) + ' ' + str(perceptronOutput.confidenceScore))
##
##print(trainer.perceptron.weights)
##
##knnOutput = trainer.generateKNN()
##print('Output KNN = ' + str(knnOutput.output) + ' ' + str(knnOutput.confidenceScore))
##
##print('Output Ensemble = ' + str(trainer.generateEnsemble()))
##
##print('Scanned ' + str(trainer.YoungScans+trainer.OldScans) + ' out of '+str(trainer.OriginalScans) + ' requested scans')
